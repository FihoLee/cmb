# Software-Devolopment
Visual studio commands for setup

npm i react
npx create-react-app my-app
cd ./my-app/

npm start
npm install -g yarn

npm i react-bootstrap
npm install react-router-dom
npm install
npm i react-native
npm install firebase@9.0.0
npm install --save react-firebase-hooks
npm install bootstrap




Github documentation steps

Git checkout -b branchname to add branch name so that you can create the new branch 
Git status to look at all files that you have edited 
Git add filename, to add all files that you want to add to the repository 
Git commit -m "message", to add message that describes what has been done 
Git push --set-upstream origin branchname, to add your branch to the main project 


for side bar
npm add react-router-dom (I think we already have this but just incase)
npm install react-icons
