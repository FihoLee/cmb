import React from 'react';

const Lessons = () => {
  return (
    <div
      style={{
        display: 'flex',
        justifyContent: 'Top',
        alignItems: 'center',
        height: '20vh'
      }}
    >

    <h1 style={{ paddingLeft: 700 }}>Lesson Plans:</h1>
    </div>

  );
};
  
export default Lessons;