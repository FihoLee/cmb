import React from 'react';

function People () {
  return (
    <div className='people'>
      <h1>People</h1>
    </div>
  );
}

export default People;