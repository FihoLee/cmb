import React from 'react';

function Settings () {
  return (
    <div className='settings'>
      <h1>Settings</h1>
    </div>
  );
}

export default Settings;